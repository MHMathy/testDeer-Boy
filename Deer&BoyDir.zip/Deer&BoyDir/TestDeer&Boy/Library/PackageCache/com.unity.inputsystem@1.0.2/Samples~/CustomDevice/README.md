This sample demonstrates how to add author a custom device that plugs into the input system.
